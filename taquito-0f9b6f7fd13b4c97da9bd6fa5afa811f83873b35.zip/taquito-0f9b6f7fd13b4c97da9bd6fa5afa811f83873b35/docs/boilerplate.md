---
title: Taquito boilerplate
author: Maksym Bykovskyy
---

Taquito boilerplate is a framework-agnostic starter kit for developing web based applications running on Tezos network.

For information about how to get started with taquito boilerplate please refer to the [Getting Started][get-started] section in the README found in the [taquito-boilerplate][repo] repository in Github.

[get-started]: https://github.com/ecadlabs/taquito-boilerplate#getting-started
[repo]: https://github.com/ecadlabs/taquito-boilerplate
