export type Falsy<T> = T | undefined | false;
